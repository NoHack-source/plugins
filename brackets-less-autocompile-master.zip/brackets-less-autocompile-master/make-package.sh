zip -9r ~/Desktop/pack.zip * -x "*/\.*" "example/*" make-package.sh
