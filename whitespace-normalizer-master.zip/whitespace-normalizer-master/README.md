Deprecation warning
=====================
This is no longer maintained, it was a small project for exploring some of Brackets' internals.
Suggested alternative is [wsSanitizer](https://github.com/MiguelCastillo/Brackets-wsSanitizer) which covers all features this project has and even more.

Whitespace Normalizer
=====================

brackets extension that features (on document save):
* trims trailing whitespaces
* transforms tabs to spaces
* ensures newline at file end

Install
=======
1. Select menu item **File > Extension Manager** in Brackets
2. Click **Install from URL** button
3. Fill in the URL **https://github.com/dsbonev/whitespace-normalizer/** and click **Install** button
4. Turn off/on extension features from **Edit** menu

Licence
=======

MIT
